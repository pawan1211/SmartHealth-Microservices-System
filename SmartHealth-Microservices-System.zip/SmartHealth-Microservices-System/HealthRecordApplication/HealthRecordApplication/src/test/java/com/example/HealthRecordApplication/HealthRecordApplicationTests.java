package com.example.HealthRecordApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthRecordApplicationTests {

	@Test
	void contextLoads() {
	}

}
